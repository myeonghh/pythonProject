import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import LinearSVC
from sklearn.datasets import load_wine
import seaborn as sns
import matplotlib.pyplot as plt


load_data = load_wine()
df = pd.DataFrame(load_data.data, columns=load_data.feature_names)
df["target"] = load_data.target
print(df.head())


# 위 df를 이용하여 Linear Regression을 진행하고 모델을 평가하라.
# 계산을 위한 랜덤seed는 0으로 고정